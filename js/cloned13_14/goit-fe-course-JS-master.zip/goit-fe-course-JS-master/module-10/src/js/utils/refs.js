export const ref = {
  ul: document.querySelector(".note-list"),
  form: document.querySelector(".note-editor"),
  input: document.querySelector(".search-form__input")
};
